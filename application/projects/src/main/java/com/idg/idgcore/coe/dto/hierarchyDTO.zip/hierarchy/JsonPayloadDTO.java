package com.idg.idgcore.coe.dto.hierarchy;

import lombok.*;

@ToString (callSuper = true)
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class JsonPayloadDTO {
    String data;
}
