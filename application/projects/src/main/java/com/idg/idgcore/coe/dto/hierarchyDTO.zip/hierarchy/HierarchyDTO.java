package com.idg.idgcore.coe.dto.hierarchy;


import com.idg.idgcore.coe.dto.mutation.PayloadDTO;
import lombok.*;
import lombok.experimental.SuperBuilder;

@ToString(callSuper = true)
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class HierarchyDTO {
    private JsonPayloadDTO jsonPayloadDTO;
}
